import java.text.DecimalFormat;

/**
 * Clase Graph que representa un grafo dirigido
 * 
 * @author Jonathan Arias Busto (UO283586)
 *
 * @param <T> Parametro que indica que permite cualquier tipo de Object
 */
public class Graph<T> {

	private double[][] weights;
	private boolean[][] edges;
	private T[] nodes;
	private int size;
	
	/**
	 * Constructor de la clase Graph que inicializa las matrices de pesos y arcos, asi
	 * como darle valor 0 a size (numero de nodos)
	 */
	public Graph(int dimension) {
		this.weights = new double[dimension][dimension];
		this.edges = new boolean[dimension][dimension];
		nodes = (T[])new Object[dimension];
		this.size = 0;
	}
	
	/**
	 * Metodo que devuelve el numero de nodos del grafo
	 * 
	 * @return Numero de nodos del grafo
	 */
	public int getSize() {
		return this.size;
	}
	
	/**
	 * Metodo que devuelve el indice, de un nodo, de la lista de nodos
	 * 
	 * @param node Nodo a buscar en la lista
	 * @return Indice del nodo en la lista de nodos
	 */
	public int getNode(T node) {
		if (node == null) return -1;
		for (int i=0;i<size;i++) {
			if (node.equals(nodes[i])) {
				return i;
			}
		}
		return -1;
	}

	/**
	 * Metodo que comprueba si un nodo existe en la lista de nodos
	 * 
	 * @param node Nodo a comprobar si existe
	 * @return <li>true: existe en la lista de nodos</li><li>false: no existe en la lista de nodos</li>
	 */
	public boolean existsNode(T node) {
		if (getNode(node) != -1) return true;
		return false;
	}
	
	/**
	 * Metodo que a�ade un nodo al grafo. Para esto se tiene que hacer una serie de comprobaciones
	 * tales como que se pueda incluir el nodo en la lista de nodos, que el nodo no existe ya en la lista...
	 * 
	 * Si el nodo se a�ade correctamente, se a�adira a la lista de nodos y las matrices de pesos y arcos en
	 * la ultima posicion
	 * 
	 * @param node Nodo a a�adir en el grafo
	 * @return <li> 0: se a�ade correctamente</li><li>-1: el nodo existe ya en la lista, pero se puede a�adir</li>
	 * <li>-2: el nodo no existe en la lista pero no hay espacio en la lista de nodos</li>
	 * <li>-3: el nodo existe en la lista y ademas no hay sitio en el en la lista de nodos</li>
	 * <li>-4: el nodo no es valido para ser a�adido</li>
	 */
	public int addNode(T node) {
		
		if (node == null) return -4;
		if (!existsNode(node) && size<nodes.length) {
			nodes[size] = node;
			
			for (int i=0; i<size; i++) {
				edges[size][i] = false;
				weights[size][i] = 0;
				edges[i][size] = false;
				weights[i][size] = 0;
			}
			++size;
			return 0;
		} else {
			if (existsNode(node) && !(size<nodes.length)) return -3;
			else if (existsNode(node) && size<nodes.length) return -1;
			else if (!existsNode(node) && !(size<nodes.length)) return -2;
		}
		return -4;
	}
	
	public double[][] getWeights() {
		return weights;
	}

	public boolean[][] getEdges() {
		return edges;
	}

	/**
	 * Metodo que comprueba si un arco existe en el grafo
	 * 
	 * @param source Nodo origen
	 * @param target Nodo destino
	 * @return <li>true: existe el arco</li><li>false: el arco no existe</li>
	 */
	public boolean existEdge(T source, T target) {
		if (existsNode(source) && existsNode(target)) {
			return edges[getNode(source)][getNode(target)];
		}
		return false;
	}
	
	
	/**
	 * Metodo que extrae el peso de un arco en caso de que este exista
	 * 
	 * @param source Nodo origen
	 * @param target Nodo destino
	 * @return <li>-1: no existe el nodo origen en la lista</li><li>-2: no existe el nodo destino en la
	 * lista</li><li>-3: no existen ni nodo origen ni nodo destino</li><li>-4: no existe arco</li><li>peso:
	 * devuelve el peso del arco en caso de existir</li>
	 */
	public double getEdge(T source, T target) {
		if (!existsNode(source) && !existsNode(target)) return -3;
		else if (!existsNode(target)) return -2;
		else if (!existsNode(source)) return -1;
		if (existEdge(source, target)) return weights[getNode(source)][getNode(target)];
		return -4;
	}
	
	/**
	 * Metodo que a�ade un arco en el grafo
	 * 
	 * @param source Nodo origen
	 * @param target Nodo destino
	 * @param weight Peso del arco
	 * @return <li>-1: no existe el nodo origen en la lista</li><li>-2: no existe el nodo destino en la
	 * lista</li><li>-3: no existen ni nodo origen ni nodo destino</li><li>-4: ya existe arco</li><li>-8:
	 * peso invalido (peso<0)</li><li>0: si se inserta el arco</li>
	 */
	public int addEdge(T source, T target, double weight) {
		if (weight < 0) return -8;
		if (!existsNode(source) && !existsNode(target)) return -3;
		else if (!existsNode(target)) return -2;
		else if (!existsNode(source)) return -1;
		if (!existEdge(source, target)) {
			edges[getNode(source)][getNode(target)] = true;
			weights[getNode(source)][getNode(target)] = weight;
			return 0;
		}
		return -4;
	}
	
	/**
	 * Metodo que borra un arco del grafo
	 * 
	 * @param source Nodo origen
	 * @param target Nodo destino
	 * @return <li>-1: no existe el nodo origen en la lista</li><li>-2: no existe el nodo destino en la
	 * lista</li><li>-3: no existen ni nodo origen ni nodo destino</li><li>-4: no existe el arco</li>
	 * <li>0: si se elimina el arco</li>
	 */
	public int removeEdge(T source, T target) {
		if (!existsNode(source) && !existsNode(target)) return -3;
		else if (!existsNode(target)) return -2;
		else if (!existsNode(source)) return -1;
		if (existEdge(source, target)) {
			edges[getNode(source)][getNode(target)] = false;
			weights[getNode(source)][getNode(target)] = 0.0;
			return 0;
		}
		return -4;
	}
	
	/**
	 * Metodo que elimina un nodo del grafo y todos los arcos que esten conectados a el
	 * 
	 * @param node Nodo a eliminar
	 * @return <li>-1: si el nodo no existe</li><li>0: se borra correctamente</li>
	 */
	public int removeNode(T node) {
		if (!existsNode(node)) return -1;
		int aux = getNode(node);
		if (getNode(node) != size) {
			nodes[getNode(node)] = nodes[size-1];
			for (int j=0;j<size;j++) {
				edges[j][aux] = edges[j][size-1];
				edges[aux][j] = edges[size-1][j];
				weights[j][aux] = weights[j][size-1];
				weights[aux][j] = weights[size-1][j];
			}
			edges[aux][aux] = edges[size-1][size-1];
			weights[aux][aux] = weights[size-1][size-1];
			--size;
			
			return 0;
		}
		return -1;
	}
	
	/**
	 * Metodo toString() de la clase Graph que devuelve una cadena de caracteres con la informacion
	 * del grafo que invoque a este.
	 * 
	 * @return Cadena con toda la informacion del grafo
	 */
	public String toString() { 
		DecimalFormat df = new DecimalFormat("#.##"); 
		String cadena = ""; 
		cadena += "NODOS\n"; 
		for (int i = 0; i < size; i++) { 
		cadena += nodes[i].toString() + "\t"; 
		} 
		cadena += "\n\nARISTAS\n"; 
		for (int i = 0; i < size; i++) { 
		for (int j = 0; j < size; j++) { 
		if (edges[i][j]) 
		cadena += "T\t"; 
		else
		cadena += "F\t"; 
		} 
		cadena += "\n"; 
		} 
		cadena += "\nPESOS\n"; 
		for (int i = 0; i < size; i++) { 
		for (int j = 0; j < size; j++) { 
		cadena += (edges[i][j]?df.format(weights[i][j]):"-") + "\t"; 
		} 
		cadena += "\n"; 
		} 
		return cadena; 
		} 
	
}
