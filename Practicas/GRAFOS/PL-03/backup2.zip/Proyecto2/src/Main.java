
public class Main {

	public static void main(String[] args) {
		Graph graph1 = new Graph<Integer>(5);
		graph1.addNode(1);
		graph1.addNode(2);
		graph1.addNode(3);
		graph1.addNode(4);
		graph1.addEdge(1, 2, 2);
		graph1.addEdge(1, 3, 1);
		graph1.addEdge(3, 2, 4);
		System.out.println(graph1.toString());
	}

}
