package AVL;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

class AVLNodeTest {

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@Test
	void test() {
		AVLNode<Integer> n = new AVLNode<Integer>(10);
		System.out.println(n.toString());
		n.setLeft(new AVLNode<Integer>(2));
//		n.setRight(new AVLNode<Integer>(12));
		System.out.println(n.getLeft().toString());
//		System.out.println(n.getRight().toString());
	
		System.out.println("Despues de actualizar");
		n.updateHeight();
		System.out.println(n.toString());
		System.out.println(n.getLeft().toString());
//		System.out.println(n.getRight().toString());
	}
	

}
