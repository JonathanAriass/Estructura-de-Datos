package AVL;

/**
 * Clase de arbol AVL
 * 
 * @author Jonathan Arias Busto (UO283586)
 *
 * @param <T>
 */
public class AVLTree <T extends Comparable<T>> {

	// Variable usada para el recorrido inOrder
	private String inOrder = "";
		
	// Variable usada para el recorrido preOrder
	private String preOrder = "";
		
	// Variable usada para el recorrido postOrder
	private String postOrder = "";
	
	private AVLNode<T> raiz; // Raiz del arbol AVL
	
	public AVLTree() {
		this.raiz = null;
	}
	
	/**
	 * VA a devolver null si la clave o el arbol en el que busco es null o no encuentra el elemento
	 * Si lo encuentra va a devolver el nodo completo
	 * @param clave Clave a buscar
	 * @return Nodo del arbol 
	 */
	public AVLNode<T> searchNode(T clave) {
		if (clave == null || this.raiz == null) return null;
		
		return search(raiz, clave);
	} //Se puede copiar el de BSTree
	
	
	private AVLNode<T> search(AVLNode<T> raiz2, T clave) {
		if (raiz2 == null) {
			return null;
		} else {
			if (clave.compareTo(raiz2.getInfo()) == 0) {
				return raiz2;
			} else {
				if (clave.compareTo(raiz2.getInfo()) > 0) {
					return search(raiz2.getRight(), clave);
				} else {
					if (clave.compareTo(raiz2.getInfo()) < 0) {
						return search(raiz2.getLeft(), clave);
					}
				}
			}
		}
		return null;
	}
	
	/**
	 * Metodo que a�ade un nodo al arbol
	 * 
	 * @param clave Nodo a a�adir 
	 * @return Numero que indica el resultado de a�adir el nodo al arbol
	 */
	public int addNode(T clave) {
		if (clave == null) return -2;
		if (searchNode(clave) != null) return -1;
		if (raiz == null) {
			this.raiz = new AVLNode(clave);
			return 0;
		}
		else {
			this.raiz = addNodeR(this.raiz, clave);
		}
		return 0;
	}
	
	/**
	 * Metodo recursivo de addNode()
	 * 
	 * @param raiz2 Raiz desde la que a�adir el nodo
	 * @param clave Clave del nodo
	 * @return Nodo con toda su informacion
	 */
	private AVLNode<T> addNodeR(AVLNode<T> raiz2, T clave) {
		if (raiz2 == null) {
			return null;
		} else {
			if (clave.compareTo(raiz2.getInfo()) < 0) {
				if (raiz2.getLeft() != null) {
					raiz2.setLeft(addNodeR(raiz2.getLeft(), clave));
					return updateAndBalanceIfNecesary(raiz2);
				} else {
					raiz2.setLeft(new AVLNode(clave));
					return updateAndBalanceIfNecesary(raiz2);
				}
			} else {
				if (clave.compareTo(raiz2.getInfo()) > 0) {
					if (raiz2.getRight() != null) {
						raiz2.setRight(addNodeR(raiz2.getRight(), clave));
						return updateAndBalanceIfNecesary(raiz2);
					} else {
						raiz2.setRight(new AVLNode(clave));
						return updateAndBalanceIfNecesary(raiz2);	
					}
				}
			}
		}
		return updateAndBalanceIfNecesary(raiz2);
	}

	/**
	 * Metodo que updatea y balancea el arbol por completo en caso de necesitar rotaciones o actualizaciones
	 * 
	 * @param nodo Nodo para el cual updatear y balancear
	 * @return Nodo actualizado
	 */
	private AVLNode<T> updateAndBalanceIfNecesary(AVLNode<T> nodo) {
		nodo.updateHeight();
		if (nodo.getBF() == -2) {
			if (nodo.getLeft().getBF() == 1) {
				nodo = doubleLeftRotation(nodo);
			} else {
				nodo = singleLeftRotation(nodo);
			}
		}
		else if (nodo.getBF() == 2) {
			if (nodo.getRight().getBF() == -1) {
				nodo = doubleRightRotation(nodo);
			} else {
				nodo = singleRightRotation(nodo);
			}
		}
		return nodo;
	}
	
	/**
	 * Metodo que realiza una rotacion simple a la izquierda
	 * 
	 * @param nodo Nodo para el cual hacer la rotacion
	 * @return Nodo rotado
	 */
	private AVLNode<T> singleLeftRotation(AVLNode<T> nodo) {
		AVLNode<T> aux = nodo.getLeft();
		nodo.setLeft(aux.getRight());
		aux.setRight(updateAndBalanceIfNecesary(nodo));
		aux.updateHeight();
		return aux;
	}
	
	/**
	 * Metodo que realiza una rotacion simple a la derecha
	 * 
	 * @param nodo Nodo para el cual hacer la rotacion
	 * @return Nodo rotado
	 */
	private AVLNode<T> singleRightRotation(AVLNode<T> nodo) {
		AVLNode<T> aux = nodo.getRight();
		nodo.setRight(aux.getLeft());
		aux.setLeft(updateAndBalanceIfNecesary(nodo));
		aux.updateHeight();
		return aux;
	}
	
	
	private AVLNode<T> doubleLeftRotation(AVLNode<T> nodo) {
		AVLNode<T> nodoAux = nodo;
		AVLNode<T> aux = nodo.getLeft();
		nodoAux.setLeft(singleRightRotation(aux));
		nodoAux = singleLeftRotation(nodoAux);
		nodoAux.updateHeight();
		return nodoAux;
	}
	
	/**
	 * RDD es una rotacionSimpleIzquierda del subarbol derecho que se tiene que a�adir al nodo raiz por la derecha
	 * y luego una rotacion simple derecha de la raizs
	 * @param nodo
	 * @return
	 */
	private AVLNode<T> doubleRightRotation(AVLNode<T> nodo) {
		AVLNode<T> nodoAux = nodo;
		AVLNode<T> aux = nodo.getRight();
		nodoAux.setRight(singleLeftRotation(aux));
		nodoAux = singleRightRotation(nodoAux);
		nodoAux.updateHeight();
		return nodoAux;
	}
	
	/**
	 * Metodo que devuelve el orden del arbol (preOrder)
	 * 
	 * @return Cadena con el arbol en preOrder
	 */
	public String preOrder() {
		this.preOrder = "";
		String cadena = preOrderR(raiz);
		return cadena.substring(0,cadena.length()-1);
	}
	
	/**
	 * Metodo recursivo auxiliar para hacer el recorrido en preOrder
	 * 
	 * @param raiz2 Raiz del arbol
	 * @return Cadena con la informacion del recorrido en preOrder
	 */
	private String preOrderR(AVLNode<T> raiz2) {
		if (raiz2 == null) return "";
		
		preOrder += raiz2.getInfo() + ":BF=" + raiz2.getBF() + "\t";
		preOrderR(raiz2.getLeft());
		preOrderR(raiz2.getRight());
		
		
		return preOrder;
	}

	/**
	 * Metodo que devuelve el orden del arbol (postOrder)
	 * 
	 * @return Cadena con el arbol en postOrder
	 */
	public String postOrder() {
		this.postOrder = "";
		String cadena = postOrderR(raiz);
		return cadena.substring(0,cadena.length()-1);
	}
	
	/**
	 * Metodo recursivo auxiliar para hacer el recorrido en postOrder
	 * 
	 * @param raiz2 Raiz del arbol
	 * @return Cadena con la informacion del recorrido en postOrder
	 */
	private String postOrderR(AVLNode<T> raiz2) {
		if (raiz2 == null) return "";
		
		postOrderR(raiz2.getLeft());
		postOrderR(raiz2.getRight());
		postOrder += raiz2.getInfo() + ":BF=" + raiz2.getBF() + "\t";
		
		
		return postOrder;
	}

	/**
	 * Metodo que devuelve el orden del arbol (inOrder)
	 * 
	 * @return Cadena con el arbol en inOrder
	 */
	public String inOrder() {
		this.inOrder = "";
		String cadena = inOrderR(raiz);
		return cadena.substring(0,cadena.length()-1);
	}
	
	/**
	 * Metodo recursivo auxiliar para hacer el recorrido en inOrder
	 * 
	 * @param raiz2 Raiz del arbol
	 * @return Cadena con la informacion del recorrido en inOrder
	 */
	private String inOrderR(AVLNode<T> raiz2) {
		if (raiz2 == null) return "";
		
		inOrderR(raiz2.getLeft());
		inOrder += raiz2.getInfo() + ":BF=" + raiz2.getBF() + "\t";
		inOrderR(raiz2.getRight());
		
		return inOrder;
	}

	/**
	 * Metodo que elimina un nodo del arbol
	 * 
	 * @param clave Clave a borrar
	 * @return Numero dependiendo del resultado de la ejecucion del programa
	 */
	public int removeNode(T clave) {
		if (this.raiz == null || clave == null) return -2;
		if (searchNode(clave) == null) return -1;
		this.raiz = removeNodeR(this.raiz, clave);
		return 0;
	}

	/**
	 * Metodo recursivo auxiliar para borrar un nodo
	 * 
	 * @param raiz2 Raiz desde el que borrar el nodo
	 * @param clave Clave a ser eliminada
	 * @return Nodo con la informacion actualizada
	 */
	private AVLNode<T> removeNodeR(AVLNode<T> raiz2, T clave) {
		if (raiz2 == null) return raiz2;
		if (clave.compareTo(raiz2.getInfo()) > 0) {
			raiz2.setRight(removeNodeR(raiz2.getRight(), clave));
			return updateAndBalanceIfNecesary(raiz2);
		} 
		else if (clave.compareTo(raiz2.getInfo()) < 0) {
			raiz2.setLeft(removeNodeR(raiz2.getLeft(), clave));
			return updateAndBalanceIfNecesary(raiz2);
		} 
		else {
			if (raiz2.getLeft() == null && raiz2.getRight() == null) {
				return null;
			} 
			else if (raiz2.getRight() != null && raiz2.getLeft() == null) {
				raiz2.setInfo(searchSucesor(raiz2).getInfo());
				raiz2.setRight(removeNodeR(raiz2.getRight(), raiz2.getInfo()));
				return updateAndBalanceIfNecesary(raiz2);
			} 
			else {
				raiz2.setInfo(searchPredecesor(raiz2).getInfo());
				raiz2.setLeft(removeNodeR(raiz2.getLeft(), raiz2.getInfo()));
				return updateAndBalanceIfNecesary(raiz2);
			}
		}
	}
	
	/**
	 * Metodo que busca el sucesor para borrar un nodo
	 * 
	 * @param raiz2 Raiz desde el que buscar un sucesor
	 * @return El sucesor 
	 */
	private AVLNode<T> searchSucesor(AVLNode<T> raiz2) {
		raiz2 = raiz2.getRight();
		while (raiz2.getLeft() != null) {
			raiz2 = raiz2.getLeft();
		}
		return raiz2;
	}

	/**
	 * Metodo que busca el predecesor para borrar un nodo
	 * 
	 * @param raiz2 Raiz desde el que buscar un predecesor
	 * @return El predecesor
	 */
	private AVLNode<T> searchPredecesor(AVLNode<T> raiz2) {
		raiz2 = raiz2.getLeft();
		while (raiz2.getRight() != null) {
			raiz2 = raiz2.getRight();
		}
		return raiz2;
	}
	
	/////////////////////////////////////////////////////////
	// 					TAREAS ADICIONALES	1			   //
	/////////////////////////////////////////////////////////
	private AVLNode<T> auxPadre = null;

	public AVLNode<T> padreDe(T clave) {
		if (clave == null) return null;
		AVLNode<T> aux = padreDeAux(this.raiz, clave);
		return aux;
	}

	
	private AVLNode<T> padreDeAux(AVLNode<T> raiz2, T clave) {
		if (raiz2 == null) {
			return null;
		} else {
			if (clave.compareTo(raiz2.getInfo()) == 0) {
				return auxPadre;
			} else {
				if (clave.compareTo(raiz2.getInfo()) > 0) {
					auxPadre = raiz2;
					return padreDeAux(raiz2.getRight(), clave);
				} else {
					if (clave.compareTo(raiz2.getInfo()) < 0) {
						auxPadre = raiz2;
						return padreDeAux(raiz2.getLeft(), clave);
					}
				}
			}
		}
		return auxPadre;
	}
}
